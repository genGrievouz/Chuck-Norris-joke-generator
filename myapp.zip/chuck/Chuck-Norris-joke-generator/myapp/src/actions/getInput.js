export const getInput = () => {
    const id = "inputvalue";
    let val = document.getElementById(id).value;
    return val;
}